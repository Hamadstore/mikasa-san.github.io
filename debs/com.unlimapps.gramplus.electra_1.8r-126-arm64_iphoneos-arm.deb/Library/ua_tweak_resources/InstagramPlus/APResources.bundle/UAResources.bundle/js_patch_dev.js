// defineClass('IGRetroRegistrationCloudIDUtils', {}, {
//     addCloudIDInformationToDictionary: function(arg1) {},
//     submitCloudIDToServerWithNetworker: function(arg1) {},
//     cloudIDQEEnabledAtAnyStep: function() {
//         return false;
//     },
//     cloudIDQEShouldRunForStep: function(arg1) {
//         return false;
//     },
// });
// defineClass('IGCloudIDValidation', {
//     storeNonceForCurrentID: function() {},
//     startCloudIDValidationWithCompletionBlock: function(arg1) {},
// });
// defineClass('CKContainer', {}, {
//     containerWithIdentifier: function(containerIdentifier) {
//         return null;
//     },
//     defaultContainer: function() {
//         return null;
//     },
// });